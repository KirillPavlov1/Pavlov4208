﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;

namespace praktika
{
	public partial class Form1 : Form
	{
		class Ball
		{
			int x, y, x1, y1, x2, y2, n = 0, k = 0;
			int w, h, w1, h1, w2, h2;

			public bool live;   // признак жизни 
			public delegate void DlTp();// Объявление типа (делегат) и 
										//создание пока что пустой ссылки для организации в последующем
										// с помощью ее вызова функции Invalidate()для главного потока
			public DlTp dl;
			public Thread thr;  //Создание ссылки на потоковый объект
								// потоковая функция
			void FnThr()
			{
				while (live)
				{
					if (x1 < 400 && k == 0 && x < 415) { x1 += 5; x += 5; } else if (x != 415) { x += 5; n = 400; k = 1; }
					if (n > 0 && x1 > 0) { x1 -= 5; }
					if (k == 1 && x2 > 0) { x2 -= 5; };
					dl();
					Thread.Sleep(80);//спим
				}
				w = 0; h = 0;
				dl();

			}


			//функция рисования 
			public void DrawBall(Graphics dc)
			{
				dc.DrawEllipse(Pens.Red, x, y, w, h);
				dc.DrawEllipse(Pens.Blue, x2, y2, w2, h2);
				dc.DrawRectangle(Pens.Red, x1, y1, w1, h1);

			}
			//конструктор класса
			public Ball(int xn, int yn, int wn, int hn)
			{
				if (xn == 0) { x = xn; y = yn; w = wn; h = hn; }//инициализируем
				if (xn == 15) { x1 = xn; y1 = yn; w1 = wn; h1 = hn; }
				if (xn == 415) { x2 = xn; y2 = yn; w2 = wn; h2 = hn; }

				thr = new Thread(new ThreadStart(FnThr)); //создаем потоковый объект
				live = true;    //устанавливаем признак жизни
				thr.Start();    //запускаем поток
			}
		}
		Ball[] bl = new Ball[5];//массив пустых ссылок типа Ball
		public Form1()
		{
			InitializeComponent();
			bl[0] = new Ball(0, 50, 30, 30);
			bl[0].dl += new Ball.DlTp(Invalidate);

			bl[1] = new Ball(0, 200, 30, 30);
			bl[1].dl += new Ball.DlTp(Invalidate);

			bl[3] = new Ball(415, 50, 30, 30);
			bl[3].dl += new Ball.DlTp(Invalidate);

			bl[2] = new Ball(415, 200, 30, 30);
			bl[2].dl += new Ball.DlTp(Invalidate);

			bl[4] = new Ball(15, 125, 30, 30);
			bl[4].dl += new Ball.DlTp(Invalidate);
		}

		private void Form1_Load(object sender, EventArgs e)
		{

		}

		private void Form1_Paint(object sender, PaintEventArgs e)
		{
			for (int j = 0; j < bl.Length; j++)
			{
				bl[j].DrawBall(e.Graphics);//рисуем
			}
		}
	}
}
